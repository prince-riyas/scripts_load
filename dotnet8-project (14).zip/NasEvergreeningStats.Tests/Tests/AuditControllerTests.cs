using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using NasEvergreeningStats.Controllers;
using NasEvergreeningStats.Services.Interfaces;
using Xunit;

namespace NasEvergreeningStats.Tests.Controllers
{
    public class AuditControllerTests
    {
        private readonly Mock<IAuditService> _mockAuditService;
        private readonly Mock<ILogger<AuditController>> _mockLogger;
        private readonly AuditController _controller;

        public AuditControllerTests()
        {
            _mockAuditService = new Mock<IAuditService>();
            _mockLogger = new Mock<ILogger<AuditController>>();
            _controller = new AuditController(_mockAuditService.Object, _mockLogger.Object);
        }

        [Fact]
        public async Task ProcessAuditRecords_ReturnsOk_WhenProcessingSucceeds()
        {
            // Arrange
            _mockAuditService.Setup(s => s.ProcessAuditRecordsAsync()).Returns(Task.CompletedTask);

            // Act
            var result = await _controller.ProcessAuditRecords();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            dynamic value = okResult.Value!;
            Assert.True(value.Success);
            Assert.Equal("Audit records processed successfully.", value.Message);
            _mockAuditService.Verify(s => s.ProcessAuditRecordsAsync(), Times.Once);
            _mockLogger.Verify(l => l.LogInformation(It.IsAny<string>()), Times.AtLeastOnce);
        }

        [Fact]
        public async Task ProcessAuditRecords_ReturnsStatusCode500_WhenServiceThrowsException()
        {
            // Arrange
            var exception = new Exception("Service failure");
            _mockAuditService.Setup(s => s.ProcessAuditRecordsAsync()).ThrowsAsync(exception);

            // Act
            var result = await _controller.ProcessAuditRecords();

            // Assert
            var statusResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal(500, statusResult.StatusCode);
            dynamic value = statusResult.Value!;
            Assert.False(value.Success);
            Assert.Equal("Error processing audit records.", value.Message);
            _mockLogger.Verify(l => l.LogError(exception, It.IsAny<string>()), Times.Once);
        }
    }
}