using Microsoft.EntityFrameworkCore;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<AuditInputRecord> AuditInputRecords { get; set; } = null!;
        public DbSet<AuditPin> AuditPins { get; set; } = null!;
        public DbSet<AuditLin> AuditLins { get; set; } = null!;
        public DbSet<AuditDinReapply> AuditDinReapplies { get; set; } = null!;

        public DbSet<DinInputRecord> DinInputRecords { get; set; } = null!;

        public DbSet<StatisticsRecord> StatisticsRecords { get; set; } = null!;

        public DbSet<ReapplyRecord> ReapplyRecords { get; set; } = null!;

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<AuditInputRecord>(entity =>
            {
                entity.HasMany(a => a.PinArray)
                      .WithOne(p => p.AuditInputRecord)
                      .HasForeignKey(p => p.AuditInputRecordId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasMany(a => a.LinArray)
                      .WithOne(l => l.AuditInputRecord)
                      .HasForeignKey(l => l.AuditInputRecordId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasMany(a => a.DinReapply)
                      .WithOne(d => d.AuditInputRecord)
                      .HasForeignKey(d => d.AuditInputRecordId)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.Property(a => a.ProcStartDate).HasMaxLength(8).IsRequired();
                entity.Property(a => a.ProcStartTime).HasMaxLength(4).IsRequired();
                entity.Property(a => a.SrcName).HasMaxLength(440).IsRequired();
                entity.Property(a => a.AddrQty).HasMaxLength(1).IsRequired();
                entity.Property(a => a.SrcAddrFrmtCd).HasMaxLength(2).IsRequired();
                entity.Property(a => a.SrcAddr).HasMaxLength(440).IsRequired();
                entity.Property(a => a.SrcNm).HasMaxLength(150);
                entity.Property(a => a.AddrLine1).HasMaxLength(60);
                entity.Property(a => a.AddrLine2).HasMaxLength(60);
                entity.Property(a => a.AddrLine3).HasMaxLength(60);
                entity.Property(a => a.AddrLine4).HasMaxLength(60);
                entity.Property(a => a.AddrLine5).HasMaxLength(60);
                entity.Property(a => a.AddrLine6).HasMaxLength(112);
                entity.Property(a => a.AddrLine7).HasMaxLength(8);
                entity.Property(a => a.QtyFromNas).HasMaxLength(1).IsRequired();
                entity.Property(a => a.AinChangeFlag).HasMaxLength(1).IsRequired();
                entity.Property(a => a.DinFoundFlag).HasMaxLength(1).IsRequired();
                entity.Property(a => a.ErrorCode).HasMaxLength(4).IsRequired();
                entity.Property(a => a.ProcessStg).HasMaxLength(1).IsRequired();
                entity.Property(a => a.FieldIndicator).HasMaxLength(1).IsRequired();
                entity.Property(a => a.DataProvider).HasMaxLength(5).IsRequired();
            });

            modelBuilder.Entity<AuditPin>(entity =>
            {
                entity.Property(p => p.Pin).IsRequired();
            });

            modelBuilder.Entity<AuditLin>(entity =>
            {
                entity.Property(l => l.Lin).IsRequired();
            });

            modelBuilder.Entity<AuditDinReapply>(entity =>
            {
                entity.Property(d => d.Din).IsRequired();
                entity.Property(d => d.SubjIdNb).IsRequired();
                entity.Property(d => d.SubjIdSeqNb).IsRequired();
            });

            modelBuilder.Entity<DinInputRecord>(entity =>
            {
                entity.Property(d => d.Din).IsRequired();
                entity.Property(d => d.SubjNb).IsRequired();
                entity.Property(d => d.SubjSeqNb).IsRequired();
            });

            modelBuilder.Entity<StatisticsRecord>(entity =>
            {
                entity.HasKey(s => s.Id);
                entity.Property(s => s.Id).ValueGeneratedNever();

                // Configure all fields as required
                entity.Property(s => s.LqRec).IsRequired();
                entity.Property(s => s.TxtRec).IsRequired();
                entity.Property(s => s.TotalExistErrorRec).IsRequired();
                entity.Property(s => s.TotalRecords).IsRequired();
                entity.Property(s => s.UnchngdAddr).IsRequired();
                entity.Property(s => s.TxtLqAinUnchg).IsRequired();
                entity.Property(s => s.LqHqAinUnchg).IsRequired();
                entity.Property(s => s.UnchgLqAinChgd).IsRequired();
                entity.Property(s => s.TxtLqAinChg).IsRequired();
                entity.Property(s => s.LqHqAinChg).IsRequired();
                entity.Property(s => s.PinCt).IsRequired();
                entity.Property(s => s.ReapplyDinCt).IsRequired();
                entity.Property(s => s.LinDeleted).IsRequired();
                entity.Property(s => s.EdbnaeCaCpu).IsRequired();
                entity.Property(s => s.EdbnaeCaElp).IsRequired();
                entity.Property(s => s.EdbnaeCbCpu).IsRequired();
                entity.Property(s => s.EdbnaeCbElp).IsRequired();
                entity.Property(s => s.EdbnaeCcCpu).IsRequired();
                entity.Property(s => s.EdbnaeCcElp).IsRequired();
                entity.Property(s => s.EdbnaeCdCpu).IsRequired();
                entity.Property(s => s.EdbnaeCdElp).IsRequired();
                entity.Property(s => s.EdbnaeCeCpu).IsRequired();
                entity.Property(s => s.EdbnaeCeElp).IsRequired();
                entity.Property(s => s.TotalTimeCpu).IsRequired();
                entity.Property(s => s.TotalTimeElp).IsRequired();
                entity.Property(s => s.TxtHqAinChg).IsRequired();
            });

            modelBuilder.Entity<ReapplyRecord>(entity =>
            {
                entity.Property(r => r.Din).IsRequired();
                entity.Property(r => r.SubjNb).IsRequired();
                entity.Property(r => r.SubjSeq).IsRequired();
                entity.Property(r => r.NoOfSubj).IsRequired();
                entity.Property(r => r.SrcProcess).IsRequired();
                entity.Property(r => r.RunDate).HasMaxLength(8).IsRequired();
            });
        }
    }
}