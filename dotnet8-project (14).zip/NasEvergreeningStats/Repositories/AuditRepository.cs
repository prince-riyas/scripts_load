using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Data;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;

namespace NasEvergreeningStats.Repositories
{
    public class AuditRepository : IAuditRepository
    {
        private readonly ApplicationDbContext _context;
        private readonly ILogger<AuditRepository> _logger;

        public AuditRepository(ApplicationDbContext context, ILogger<AuditRepository> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<AuditInputRecord>> GetAllAsync()
        {
            _logger.LogInformation("Fetching all audit input records.");
            return await _context.AuditInputRecords
                .Include(a => a.PinArray)
                .Include(a => a.LinArray)
                .Include(a => a.DinReapply)
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<AuditInputRecord?> GetByIdAsync(long id)
        {
            _logger.LogInformation("Fetching audit input record with Id: {Id}", id);
            return await _context.AuditInputRecords
                .Include(a => a.PinArray)
                .Include(a => a.LinArray)
                .Include(a => a.DinReapply)
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task AddAsync(AuditInputRecord auditRecord)
        {
            _logger.LogInformation("Adding new audit input record.");
            await _context.AuditInputRecords.AddAsync(auditRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(AuditInputRecord auditRecord)
        {
            _logger.LogInformation("Updating audit input record with Id: {Id}", auditRecord.Id);
            _context.AuditInputRecords.Update(auditRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteAsync(long id)
        {
            _logger.LogInformation("Deleting audit input record with Id: {Id}", id);
            var entity = await _context.AuditInputRecords.FindAsync(id);
            if (entity != null)
            {
                _context.AuditInputRecords.Remove(entity);
                await _context.SaveChangesAsync();
            }
        }
    }
}