using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IReapplyRepository
    {
        Task<IEnumerable<ReapplyRecord>> GetAllAsync();
        Task AddAsync(ReapplyRecord reapplyRecord);
        Task AddRangeAsync(IEnumerable<ReapplyRecord> reapplyRecords);
        Task DeleteAllAsync();
    }
}