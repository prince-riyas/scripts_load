using System.Collections.Generic;
using System.Threading.Tasks;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Repositories.Interfaces
{
    public interface IDinRepository
    {
        Task<IEnumerable<DinInputRecord>> GetAllAsync();
        Task<DinInputRecord?> GetByIdAsync(long id);
        Task AddAsync(DinInputRecord dinRecord);
        Task UpdateAsync(DinInputRecord dinRecord);
        Task DeleteAsync(long id);
    }
}