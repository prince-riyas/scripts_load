using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface ILoggingService
    {
        Task LogInformationAsync(string message, params object[] args);
        Task LogErrorAsync(string message, params object[] args);
        Task LogErrorAsync(System.Exception exception, string message, params object[] args);
    }
}