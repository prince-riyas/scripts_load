using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IParameterValidationService
    {
        Task ValidateLoggingLevelAsync(string loggingLevel);
        Task ValidateCallModeAsync(string callMode);
    }
}