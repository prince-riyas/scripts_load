using System.Threading.Tasks;
using NasEvergreeningStats.Models.Entities;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IAuditService
    {
        Task ProcessAuditRecordsAsync();
        Task<int> GetErroredRecordCountAsync();
        Task<int> GetPinCountAsync();
        Task<int> GetLinCountAsync();
    }
}