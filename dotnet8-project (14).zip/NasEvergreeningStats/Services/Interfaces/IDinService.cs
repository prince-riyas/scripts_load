using System.Threading.Tasks;

namespace NasEvergreeningStats.Services.Interfaces
{
    public interface IDinService
    {
        Task ProcessDinRecordsAsync(string callMode);
    }
}