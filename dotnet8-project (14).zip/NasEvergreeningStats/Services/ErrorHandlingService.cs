using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class ErrorHandlingService : IErrorHandlingService
    {
        private readonly ILogger<ErrorHandlingService> _logger;

        public ErrorHandlingService(ILogger<ErrorHandlingService> logger)
        {
            _logger = logger;
        }

        public Task HandleErrorAsync(Exception exception, string section)
        {
            _logger.LogError(exception, "Error in section: {Section}", section);
            // In production, could trigger alerts, cleanup, or graceful shutdown
            return Task.CompletedTask;
        }
    }
}