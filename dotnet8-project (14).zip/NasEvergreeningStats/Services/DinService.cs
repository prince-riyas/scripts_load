using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Models.Entities;
using NasEvergreeningStats.Repositories.Interfaces;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Services
{
    public class DinService : IDinService
    {
        private readonly IDinRepository _dinRepository;
        private readonly IReapplyRepository _reapplyRepository;
        private readonly ILogger<DinService> _logger;

        public DinService(IDinRepository dinRepository, IReapplyRepository reapplyRepository, ILogger<DinService> logger)
        {
            _dinRepository = dinRepository;
            _reapplyRepository = reapplyRepository;
            _logger = logger;
        }

        public async Task ProcessDinRecordsAsync(string callMode)
        {
            _logger.LogInformation("Starting processing of DIN records with call mode: {CallMode}", callMode);

            if (string.IsNullOrWhiteSpace(callMode))
            {
                throw new ArgumentException("Call mode must be provided and non-empty.", nameof(callMode));
            }

            try
            {
                var dinRecords = await _dinRepository.GetAllAsync();

                if (dinRecords == null)
                {
                    _logger.LogInformation("No DIN records found to process.");
                    return;
                }

                if (callMode.Equals("U", StringComparison.OrdinalIgnoreCase))
                {
                    // Update mode: generate reapply records
                    var reapplyRecords = new List<ReapplyRecord>();

                    foreach (var din in dinRecords)
                    {
                        var reapplyRecord = new ReapplyRecord
                        {
                            Din = din.Din,
                            SubjNb = din.SubjNb,
                            SubjSeq = din.SubjSeqNb,
                            NoOfSubj = 1, // Default to 1, logic can be enhanced
                            SrcProcess = 0, // Placeholder, actual logic to determine source process
                            RunDate = DateTime.UtcNow.ToString("yyyyMMdd")
                        };
                        reapplyRecords.Add(reapplyRecord);
                    }

                    await _reapplyRepository.DeleteAllAsync();
                    await _reapplyRepository.AddRangeAsync(reapplyRecords);

                    _logger.LogInformation("Reapply records generated and saved for {Count} DIN records.", reapplyRecords.Count);
                }
                else if (callMode.Equals("R", StringComparison.OrdinalIgnoreCase))
                {
                    // Read mode: no reapply file generation
                    _logger.LogInformation("Read mode selected, no reapply file generation performed.");
                }
                else
                {
                    throw new ArgumentException("Invalid call mode. Allowed values are 'U' (Update) or 'R' (Read).", nameof(callMode));
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while processing DIN records.");
                throw;
            }
        }
    }
}