using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NasEvergreeningStats.Services.Interfaces;

namespace NasEvergreeningStats.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StatisticsController : ControllerBase
    {
        private readonly IStatisticsService _statisticsService;
        private readonly ILogger<StatisticsController> _logger;

        public StatisticsController(IStatisticsService statisticsService, ILogger<StatisticsController> logger)
        {
            _statisticsService = statisticsService;
            _logger = logger;
        }

        [HttpGet("display")]
        public async Task<IActionResult> GetDisplayStatistics()
        {
            _logger.LogInformation("API call to get display statistics.");

            try
            {
                var displayStats = await _statisticsService.GenerateDisplayStatisticsAsync();
                return Ok(displayStats);
            }
            catch (System.Exception ex)
            {
                _logger.LogError(ex, "Error retrieving display statistics.");
                return StatusCode(500, new { Success = false, Message = "Error retrieving display statistics." });
            }
        }
    }
}