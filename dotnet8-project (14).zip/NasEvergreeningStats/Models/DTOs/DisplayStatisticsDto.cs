using System.ComponentModel.DataAnnotations;

namespace NasEvergreeningStats.Models.DTOs
{
    public class DisplayStatisticsDto
    {
        [Required]
        [StringLength(40)]
        public string Header { get; set; } = string.Empty;

        [Required]
        [Range(0, long.MaxValue)]
        public long Detail { get; set; }
    }
}