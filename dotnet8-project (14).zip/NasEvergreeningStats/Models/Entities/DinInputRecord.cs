using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("DinInputRecords")]
    public class DinInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        public long Din { get; set; } // D-INP-DIN PIC S9(18) COMP

        [Required]
        public int SubjNb { get; set; } // D-INP-SUBJ-NB PIC S9(04) COMP

        [Required]
        public int SubjSeqNb { get; set; } // D-INP-SUBJ-SEQ-NB PIC S9(04) COMP
    }
}