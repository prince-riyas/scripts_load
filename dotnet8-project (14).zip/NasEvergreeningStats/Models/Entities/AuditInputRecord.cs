using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("AuditInputRecords")]
    public class AuditInputRecord
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public long Id { get; set; }

        [Required]
        [StringLength(8)]
        public string ProcStartDate { get; set; } = string.Empty; // N-PROC-START-DT PIC X(08)

        [Required]
        [StringLength(4)]
        public string ProcStartTime { get; set; } = string.Empty; // N-PROC-START-TM PIC X(04)

        [Required]
        public long NasevgDin { get; set; } // N-NASEVG-DIN PIC S9(18) COMP

        [Required]
        public long SrcDin { get; set; } // N-SRC-DIN PIC S9(18) COMP

        [Required]
        public int SrcSubjIdNb { get; set; } // N-SRC-SUBJ-ID-NB PIC S9(04) COMP

        [Required]
        public int SrcSubjSeqNb { get; set; } // N-SRC-SUBJ-SEQ-NB PIC S9(04) COMP

        [Required]
        public long SrcRef { get; set; } // N-SRC-REF PIC S9(18) COMP

        [Required]
        [StringLength(440)]
        public string SrcName { get; set; } = string.Empty; // N-SRC-NAME PIC X(440)

        [Required]
        public int SrcAin { get; set; } // N-SRC-AIN PIC S9(09) COMP

        [Required]
        [StringLength(1)]
        public string AddrQty { get; set; } = string.Empty; // N-ADDR-QTY PIC X(01)

        [Required]
        [StringLength(2)]
        public string SrcAddrFrmtCd { get; set; } = string.Empty; // N-SRC-ADDR-FRMT-CD PIC X(02)

        [Required]
        [StringLength(440)]
        public string SrcAddr { get; set; } = string.Empty; // N-SRC-ADDR PIC X(440)

        // Formatted Address Lines
        [StringLength(150)]
        public string SrcNm { get; set; } = string.Empty; // N-SRC-NM PIC X(150)

        [StringLength(60)]
        public string AddrLine1 { get; set; } = string.Empty; // N-ADDR-LINE1 PIC X(60)

        [StringLength(60)]
        public string AddrLine2 { get; set; } = string.Empty; // N-ADDR-LINE2 PIC X(60)

        [StringLength(60)]
        public string AddrLine3 { get; set; } = string.Empty; // N-ADDR-LINE3 PIC X(60)

        [StringLength(60)]
        public string AddrLine4 { get; set; } = string.Empty; // N-ADDR-LINE4 PIC X(60)

        [StringLength(60)]
        public string AddrLine5 { get; set; } = string.Empty; // N-ADDR-LINE5 PIC X(60)

        [StringLength(112)]
        public string AddrLine6 { get; set; } = string.Empty; // N-ADDR-LINE6 PIC X(112)

        [StringLength(8)]
        public string AddrLine7 { get; set; } = string.Empty; // N-ADDR-LINE7 PIC X(08)

        [Required]
        public int AinFromNas { get; set; } // N-AIN-FROM-NAS PIC S9(09) COMP

        [Required]
        [StringLength(1)]
        public string QtyFromNas { get; set; } = string.Empty; // N-QTY-FROM-NAS PIC X(01)

        [Required]
        [StringLength(1)]
        public string AinChangeFlag { get; set; } = string.Empty; // N-AIN-CHANGE-FLAG PIC X(01)

        [Required]
        [StringLength(1)]
        public string DinFoundFlag { get; set; } = string.Empty; // N-DIN-FOUND-FLAG PIC X(01)

        [Required]
        [StringLength(4)]
        public string ErrorCode { get; set; } = string.Empty; // N-ERROR-CODE PIC X(04)

        [Required]
        [StringLength(1)]
        public string ProcessStg { get; set; } = string.Empty; // N-PROCESS-STG PIC X(01)

        [Required]
        [StringLength(1)]
        public string FieldIndicator { get; set; } = string.Empty; // N-FIELD-INDICATOR PIC X(01)

        [Required]
        [StringLength(5)]
        public string DataProvider { get; set; } = string.Empty; // N-DATA-PROVIDER PIC X(05)

        [Required]
        public int SequenceNb { get; set; } // N-SEQUENCE-NB PIC 9(06)

        [Required]
        public short PinCount { get; set; } // N-PIN-COUNT PIC S9(04) COMP

        [Required]
        public short NonStdLinCount { get; set; } // N-NON-STD-LIN-COUNT PIC S9(04) COMP

        [Required]
        public short DinCount { get; set; } // N-DIN-COUNT PIC S9(04) COMP

        // Collections for OCCURS
        public ICollection<AuditPin> PinArray { get; set; } = new List<AuditPin>();

        public ICollection<AuditLin> LinArray { get; set; } = new List<AuditLin>();

        public ICollection<AuditDinReapply> DinReapply { get; set; } = new List<AuditDinReapply>();
    }

    [Table("AuditPinArray")]
    public class AuditPin
    {
        [Key]
        public long Id { get; set; }

        [Required]
        public int Pin { get; set; } // N-PIN PIC S9(09) COMP

        [ForeignKey("AuditInputRecord")]
        public long AuditInputRecordId { get; set; }

        public AuditInputRecord AuditInputRecord { get; set; } = null!;
    }

    [Table("AuditLinArray")]
    public class AuditLin
    {
        [Key]
        public long Id { get; set; }

        [Required]
        public int Lin { get; set; } // N-LIN PIC S9(09) COMP

        [ForeignKey("AuditInputRecord")]
        public long AuditInputRecordId { get; set; }

        public AuditInputRecord AuditInputRecord { get; set; } = null!;
    }

    [Table("AuditDinReapplyArray")]
    public class AuditDinReapply
    {
        [Key]
        public long Id { get; set; }

        [Required]
        public long Din { get; set; } // N-DIN PIC S9(18) COMP

        [Required]
        public int SubjIdNb { get; set; } // N-SUBJ-ID-NB PIC S9(04) COMP

        [Required]
        public int SubjIdSeqNb { get; set; } // N-SUBJ-ID-SEQ-NB PIC S9(04) COMP

        [ForeignKey("AuditInputRecord")]
        public long AuditInputRecordId { get; set; }

        public AuditInputRecord AuditInputRecord { get; set; } = null!;
    }
}