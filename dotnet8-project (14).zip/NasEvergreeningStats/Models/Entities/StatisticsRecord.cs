using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NasEvergreeningStats.Models.Entities
{
    [Table("StatisticsRecords")]
    public class StatisticsRecord
    {
        [Key]
        public int Id { get; set; } = 1; // Single row table with PK=1

        [Required]
        public int LqRec { get; set; } // PFX-LQ-REC PIC 9(08)

        [Required]
        public int TxtRec { get; set; } // PFX-TXT-REC PIC 9(08)

        [Required]
        public int TotalExistErrorRec { get; set; } // PFX-TOTAL-EXIST-ERROR-REC PIC 9(08)

        [Required]
        public int TotalRecords { get; set; } // PFX-TOTAL-RECORDS PIC 9(08)

        [Required]
        public int UnchngdAddr { get; set; } // PFX-UNCHNGD-ADDR PIC 9(08)

        [Required]
        public int TxtLqAinUnchg { get; set; } // PFX-TXT-LQ-AIN-UNCHG PIC 9(08)

        [Required]
        public int LqHqAinUnchg { get; set; } // PFX-LQ-HQ-AIN-UNCHG PIC 9(08)

        [Required]
        public int UnchgLqAinChgd { get; set; } // PFX-UNCHG-LQ-AIN-CHGD PIC 9(08)

        [Required]
        public int TxtLqAinChg { get; set; } // PFX-TXT-LQ-AIN-CHG PIC 9(08)

        [Required]
        public int LqHqAinChg { get; set; } // PFX-LQ-HQ-AIN-CHG PIC 9(08)

        [Required]
        public int PinCt { get; set; } // PFX-PIN-CT PIC 9(08)

        [Required]
        public int ReapplyDinCt { get; set; } // PFX-REAPPLY-DIN-CT PIC 9(08)

        [Required]
        public int LinDeleted { get; set; } // PFX-LIN-DELETED PIC 9(08)

        [Required]
        public long EdbnaeCaCpu { get; set; } // PFX-EDBNAECA-CPU PIC 9(17)

        [Required]
        public int EdbnaeCaElp { get; set; } // PFX-EDBNAECA-ELP PIC 9(08)

        [Required]
        public long EdbnaeCbCpu { get; set; } // PFX-EDBNAECB-CPU PIC 9(17)

        [Required]
        public int EdbnaeCbElp { get; set; } // PFX-EDBNAECB-ELP PIC 9(08)

        [Required]
        public long EdbnaeCcCpu { get; set; } // PFX-EDBNAECC-CPU PIC 9(17)

        [Required]
        public int EdbnaeCcElp { get; set; } // PFX-EDBNAECC-ELP PIC 9(08)

        [Required]
        public long EdbnaeCdCpu { get; set; } // PFX-EDBNAECD-CPU PIC 9(17)

        [Required]
        public int EdbnaeCdElp { get; set; } // PFX-EDBNAECD-ELP PIC 9(08)

        [Required]
        public long EdbnaeCeCpu { get; set; } // PFX-EDBNAECE-CPU PIC 9(17)

        [Required]
        public int EdbnaeCeElp { get; set; } // PFX-EDBNAECE-ELP PIC 9(08)

        [Required]
        public long TotalTimeCpu { get; set; } // PFX-TOTAL-TIME-CPU PIC 9(17)

        [Required]
        public int TotalTimeElp { get; set; } // PFX-TOTAL-TIME-ELP PIC 9(08)

        [Required]
        public int TxtHqAinChg { get; set; } // PFX-TXT-HQ-AIN-CHG PIC 9(08)
    }
}